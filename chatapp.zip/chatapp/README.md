# 🔵 ZanaChat — App ya Mazungumzo ya Wakati Halisi

App ya chat kamili kama WhatsApp, iliyotengenezwa kwa Node.js + Socket.io.

## ✅ Vipengele

- 🔐 Usajili na kuingia (Login/Register)
- 💬 Mazungumzo ya moja kwa moja (DMs)
- 👥 Vikundi vya mazungumzo
- 🟢 Kuona nani yuko mtandaoni
- ⌨️ Kuona mtu anaandika (typing indicator)
- 📷 Kutuma picha
- 🔔 Arifa za ujumbe
- 📱 Inafanya kazi kwenye simu na kompyuta

---

## 🚀 Jinsi ya Kuanza

### Hatua 1: Sakinisha Node.js
Pakua Node.js kutoka: https://nodejs.org (toleo 18+)

### Hatua 2: Fungua folda ya mradi
```bash
cd chatapp
```

### Hatua 3: Sakinisha vifurushi
```bash
npm install
```

### Hatua 4: Anza server
```bash
npm start
```

### Hatua 5: Fungua browser
Nenda: http://localhost:3000

---

## 🌐 Deploy kwenye Internet (Railway - Bure)

1. Nenda https://railway.app
2. Jiandikishe kwa GitHub
3. Bonyeza "New Project" → "Deploy from GitHub"
4. Pakia code yako GitHub kwanza, kisha connect
5. Weka environment variable:
   ```
   JWT_SECRET=nywila-yako-ya-siri-hapa-badilisha
   PORT=3000
   ```
6. Railway itakupa URL ya app yako!

---

## 📁 Muundo wa Faili

```
chatapp/
├── server.js          ← Backend (Node.js + Socket.io)
├── package.json       ← Dependencies
├── chatapp.db         ← Database (inaundwa otomatiki)
└── public/
    ├── index.html     ← Frontend (HTML + CSS + JS)
    └── uploads/       ← Picha zilizotumwa
```

---

## ⚙️ Mabadiliko ya Lazima kwa Production

Hariri `server.js`, mstari huu:
```javascript
const JWT_SECRET = process.env.JWT_SECRET || 'badilisha-secret-hii-kwa-production';
```

Badilisha kuwa environment variable tu:
```javascript
const JWT_SECRET = process.env.JWT_SECRET;
```

---

## 📞 Maswali?

Omba msaada wa Claude kwa maboresho zaidi!
